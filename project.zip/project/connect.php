<?php
	$sname = $_POST['sname'];
	$fname = $_POST['fname'];
	$mname = $_POST['mname'];
	$sdob = $_POST['sdob'];
	$sg = $_POST['sg'];
	$parphone = $_POST['parphone'];
	$sphone = $_POST['sphone'];
	$fmail = $_POST['fmail'];
	$smail = $_POST['smail'];
	$sbranch = $_POST['sbranch'];
	// Database connectionphp
	$conn = new mysqli('localhost','root');

	if($conn->connect_error){
		echo "$conn->connect_error";
		die("Connection Failed : ". $conn->connect_error);
	} else {
		$stmt = $conn->prepare("insert into registration(sname, fname, mname, sdob, sg, parphone, sphone, fmail,  smail, sbranch) values(?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
		$stmt->bind_param("sssssiisss", $sname, $fname, $mname, $sdob, $sg, $parphone, $sphone, $fmail, $smail, $sbranch);
		$execval = $stmt->execute();
		echo $execval;
		echo "Registration successfully...";
		$stmt->close();
		$conn->close();
	}
?>